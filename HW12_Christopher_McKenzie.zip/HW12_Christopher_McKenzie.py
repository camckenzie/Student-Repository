"""Christopher McKenzie
The purpose of this program is to create a web page to display the
new student grades pretty table from HW11 as a web page.
"""

from flask import Flask, render_template, request
from typing import Dict, List, Tuple
import sqlite3

app: Flask = Flask(__name__)

DB_FILE: str = r"C:\Users\Chris\Desktop\HW11\HW11_Database.db"

@app.route('/repository')

def stevens_repository() -> str:

    """Defines query from SQLite database, converts results into list
    of dictionaries, and creates new webpage with all results in a
    table using base_template and stevens_form.
    """

    query: str = """select s.name, s.cwid, g.course, g.grade, i.name
                    from students s
                        join grades g on s.cwid=g.StudentCWID
                        join instructors i on i.CWID=g.InstructorCWID
                        order by s.name"""

    db: sqlite3.Connection = sqlite3.connect(DB_FILE)
    
    # Converts the query results into a list of dictionaries that is passed into the template
    rows: List[Dict[str, str]] = \
        [{'student': student, 'cwid': cwid, 'course': course, 'grade': grade, 'instructor': instructor} \
        for student, cwid, course, grade, instructor in db.execute(query)]
    
    db.close()

    return render_template('stevens_form.html',
                            title='Stevens Repository',
                            table_title='Student, Course, Grade, and Instructor',
                            rows=rows
                            )


app.run(debug=True)